//
//  PHAsset+PHAsset_getTitle.h
//  photo_manager
//
//  Created by Caijinglong on 2020/1/15.
//

#import <Photos/Photos.h>

NS_ASSUME_NONNULL_BEGIN

@interface PHAsset (PHAsset_getTitle)

- (NSString*)title;

@end

NS_ASSUME_NONNULL_END
