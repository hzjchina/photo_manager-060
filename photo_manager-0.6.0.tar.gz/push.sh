export http_proxy=http://127.0.0.1:1087;export https_proxy=http://127.0.0.1:1087;
flutter pub pub publish --server https://pub.dev