//
//  Bridge.m
//  Runner
//
//  Created by cjl on 2020/5/15.
//  Copyright © 2020 The Flutter Authors. All rights reserved.
//

#import "Bridge.h"

@implementation Bridge

@end
