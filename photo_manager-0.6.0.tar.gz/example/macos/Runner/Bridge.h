//
//  Bridge.h
//  Runner
//
//  Created by cjl on 2020/5/15.
//  Copyright © 2020 The Flutter Authors. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Bridge : NSObject

@end

NS_ASSUME_NONNULL_END
