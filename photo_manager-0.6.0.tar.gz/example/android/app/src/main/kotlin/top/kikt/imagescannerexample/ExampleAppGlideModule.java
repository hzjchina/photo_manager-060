package top.kikt.imagescannerexample;
/// create 2020/5/19 by cai

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public class ExampleAppGlideModule extends AppGlideModule {



}
