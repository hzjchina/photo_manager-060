import 'package:flutter/material.dart';

class DebugInfoForThumbExample extends StatefulWidget {
  @override
  _DebugInfoForThumbExampleState createState() =>
      _DebugInfoForThumbExampleState();
}

class _DebugInfoForThumbExampleState extends State<DebugInfoForThumbExample> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
