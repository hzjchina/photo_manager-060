一些帮助开发者开发的日志

安卓日志来源: https://gitee.com/kikt/media_store_simple_utils 运行的项目
