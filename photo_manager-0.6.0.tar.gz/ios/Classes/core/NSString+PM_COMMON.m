//
// Created by Caijinglong on 2020/3/20.
//

#import "NSString+PM_COMMON.h"

@implementation NSString (PM_COMMON)

- (BOOL)isEmpty{
  return [self isEqualToString:@""];
}

@end
