//
//  AssetEntity.m
//  photo_manager
//
//  Created by Caijinglong on 2018/10/19.
//

#import "AssetEntity.h"

@implementation AssetEntity

@end
