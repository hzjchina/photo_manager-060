#import <Flutter/Flutter.h>

@interface ImageScannerPlugin : NSObject <FlutterPlugin>
@property(nonatomic, strong) NSObject <FlutterPluginRegistrar> *registrar;
@end